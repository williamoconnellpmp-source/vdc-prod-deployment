import os, json, uuid
from datetime import datetime, timezone
import boto3

ddb = boto3.resource("dynamodb")
s3 = boto3.client("s3")

# ---------- helpers ----------

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()

def resp(code, body):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN", "*"),
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body),
    }

class AuthError(Exception):
    def __init__(self, status_code: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.details = details or {}

def _get_claims(event):
    """
    HTTP API JWT authorizer typically:
      event.requestContext.authorizer.jwt.claims
    """
    rc = event.get("requestContext", {}) or {}
    authz = rc.get("authorizer", {}) or {}

    jwt_block = authz.get("jwt", {}) or {}
    claims = jwt_block.get("claims")
    if claims:
        return claims

    # fallback shape sometimes seen
    if "claims" in authz and authz.get("claims"):
        return authz.get("claims")

    return None

def _normalize_groups(groups_val):
    """
    Normalize Cognito groups to list[str].
    Supports: list, string, "A,B", JSON string '["A"]', bracketed "[A]"
    """
    if groups_val is None:
        return []

    if isinstance(groups_val, list):
        return [str(g).strip() for g in groups_val if str(g).strip()]

    if isinstance(groups_val, str):
        s = groups_val.strip()
        if not s:
            return []

        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(g).strip() for g in arr if str(g).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip().strip('"').strip("'") for p in inner.split(",") if p.strip()]
                return [p.strip().strip('"').strip("'") for p in inner.split() if p.strip()]

        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]

        return [s]

    return [str(groups_val).strip()]

def _require_authz(event):
    claims = _get_claims(event)
    if not claims:
        raise AuthError(401, "Unauthorized (no JWT claims found)")

    actor_sub = claims.get("sub")
    if not actor_sub:
        raise AuthError(401, "Unauthorized (missing sub claim)")

    groups = _normalize_groups(claims.get("cognito:groups"))
    actor = {
        "sub": actor_sub,
        "email": claims.get("email"),
        "username": claims.get("cognito:username") or claims.get("username") or claims.get("email") or actor_sub,
        "groups": groups,
    }
    return actor

def _is_approver(actor):
    groups = [g.lower() for g in (actor.get("groups") or [])]
    return ("approver" in groups) or ("approvers" in groups)

def _audit_download(table, pk, doc_id, actor, meta, now, event):
    audit_id = str(uuid.uuid4())
    item = {
        "pk": pk,
        "sk": f"AUDIT#{now}#{audit_id}",
        "eventId": audit_id,
        "eventType": "DOC_DOWNLOADED",
        "timestampUtc": now,
        "actorUserId": actor.get("sub"),
        "actorUsername": actor.get("username"),
        "actorEmail": actor.get("email"),
        "actorGroups": actor.get("groups", []),
        "details": {
            "env": os.environ.get("ENV_NAME", "dev"),
            "apiRequestId": event.get("requestContext", {}).get("requestId"),
            "routeKey": event.get("routeKey"),
        },
        "integrity": {
            "s3Bucket": meta.get("s3Bucket"),
            "s3Key": meta.get("s3Key"),
            "s3VersionId": meta.get("s3VersionId"),
            "sha256": meta.get("sha256"),
        },
    }
    table.put_item(Item=item)

# ---------- handler ----------

def handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if method == "OPTIONS":
        return resp(200, {"ok": True})
    if method != "GET":
        return resp(405, {"error": "Method not allowed"})

    # authn
    try:
        actor = _require_authz(event)
    except AuthError as e:
        body = {"error": e.message}
        if e.details:
            body["details"] = e.details
        return resp(e.status_code, body)

    doc_id = (event.get("pathParameters") or {}).get("documentId")
    if not doc_id:
        return resp(400, {"error": "documentId missing in path"})

    table_name = os.environ.get("DDB_TABLE")
    if not table_name:
        return resp(500, {"error": "Server misconfigured: DDB_TABLE env var missing"})

    table = ddb.Table(table_name)
    pk = f"DOC#{doc_id}"

    meta = table.get_item(Key={"pk": pk, "sk": "METADATA"}).get("Item")
    if not meta:
        return resp(404, {"error": "Document not found"})

    # authorization: Approver OR Owner
    owner_user_id = meta.get("ownerUserId")
    if not _is_approver(actor):
        if not owner_user_id or owner_user_id != actor.get("sub"):
            return resp(
                403,
                {
                    "error": "Forbidden: only the document owner or an Approver can download this file",
                    "details": {
                        "isApprover": False,
                        "ownerUserIdPresent": bool(owner_user_id),
                    },
                },
            )

    bucket = meta.get("s3Bucket")
    key = meta.get("s3Key")
    if not bucket or not key:
        return resp(500, {"error": "Document metadata missing s3Bucket/s3Key"})

    filename = key.split("/")[-1]
    content_type = meta.get("contentType") or "application/octet-stream"
    expires_in = int(os.environ.get("DOWNLOAD_TTL_SECONDS", "300"))

    try:
        url = s3.generate_presigned_url(
            "get_object",
            Params={
                "Bucket": bucket,
                "Key": key,
                "ResponseContentDisposition": f'attachment; filename="{filename}"',
                "ResponseContentType": content_type,
            },
            ExpiresIn=expires_in,
        )
    except Exception as e:
        return resp(500, {"error": f"Failed to create presigned download URL: {str(e)}"})

    # audit event (best-effort; don't block download if audit write fails)
    try:
        now = utc_now_iso()
        _audit_download(table, pk, doc_id, actor, meta, now, event)
    except Exception as e:
        print("WARN audit write failed:", str(e))

    return resp(
        200,
        {
            "documentId": doc_id,
            "fileName": filename,
            "s3Bucket": bucket,
            "s3Key": key,
            "expiresInSeconds": expires_in,
            "downloadUrl": url,
        },
    )
