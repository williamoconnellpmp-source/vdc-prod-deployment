import os, json, uuid
from datetime import datetime, timezone
import boto3

ddb = boto3.resource("dynamodb")


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()


def resp(code, body):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN", "*"),
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body)
    }


class AuthError(Exception):
    def __init__(self, status_code: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.details = details or {}


def _get_claims(event):
    """
    HTTP API JWT authorizer typically: event.requestContext.authorizer.jwt.claims
    """
    rc = event.get("requestContext", {}) or {}
    authz = rc.get("authorizer", {}) or {}

    jwt_block = authz.get("jwt", {}) or {}
    claims = jwt_block.get("claims")
    if claims:
        return claims

    if "claims" in authz and authz.get("claims"):
        return authz.get("claims")

    return None


def _normalize_groups(groups_val):
    """
    Normalize Cognito groups to list[str].

    Possible shapes:
      - list: ["Approver"]
      - string: "Approver"
      - string: "Approver,Uploader"
      - JSON string: '["Approver","Uploader"]'
      - bracketed non-JSON string: "[Approver]" or "[Approver,Uploader]"
    """
    if groups_val is None:
        return []

    # Already a list
    if isinstance(groups_val, list):
        return [str(g).strip() for g in groups_val if str(g).strip()]

    # String cases
    if isinstance(groups_val, str):
        s = groups_val.strip()
        if not s:
            return []

        # JSON list encoded as string
        if s.startswith("[") and s.endswith("]"):
            # Try real JSON first
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(g).strip() for g in arr if str(g).strip()]
            except Exception:
                # Handle non-JSON like: [Approver] or [Approver,Uploader]
                inner = s[1:-1].strip()
                if not inner:
                    return []
                # split on comma if present, else split on whitespace
                if "," in inner:
                    parts = [p.strip().strip('"').strip("'") for p in inner.split(",") if p.strip()]
                    return parts
                parts = [p.strip().strip('"').strip("'") for p in inner.split() if p.strip()]
                return parts

        # Comma-separated
        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]

        # Single group
        return [s]

    # Anything else
    return [str(groups_val).strip()]


def _normalize_amr(amr_val):
    """
    Normalize 'amr' to list[str].
    Often missing for Cognito User Pools access tokens.
    """
    if amr_val is None:
        return []

    if isinstance(amr_val, list):
        return [str(a).strip() for a in amr_val if str(a).strip()]

    if isinstance(amr_val, str):
        s = amr_val.strip()
        if not s:
            return []

        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(a).strip() for a in arr if str(a).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip() for p in inner.split(",") if p.strip()]
                return [p.strip() for p in inner.split() if p.strip()]

        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]
        return [p.strip() for p in s.split(" ") if p.strip()]

    return [str(amr_val).strip()]


def _require_authz(event):
    claims = _get_claims(event)
    if not claims:
        raise AuthError(401, "Unauthorized (no JWT claims found)")

    actor_sub = claims.get("sub")
    actor_email = claims.get("email")
    actor_username = (
        claims.get("cognito:username")
        or claims.get("username")
        or actor_email
        or actor_sub
    )

    groups = _normalize_groups(claims.get("cognito:groups"))
    amr = _normalize_amr(claims.get("amr"))
    auth_time = claims.get("auth_time")

    actor = {
        "sub": actor_sub,
        "email": actor_email,
        "username": actor_username,
        "groups": groups,
        "amr": amr,
        "auth_time": auth_time
    }

    # DEBUG
    print("DEBUG claims keys:", list(claims.keys()))
    print("DEBUG raw cognito:groups:", claims.get("cognito:groups"))
    print("DEBUG normalized groups:", groups)
    print("DEBUG raw amr:", claims.get("amr"))
    print("DEBUG normalized amr:", amr)

    return actor


def _require_group(actor, group_name):
    groups = actor.get("groups", []) or []
    if group_name in groups:
        return

    # case-insensitive fallback
    if group_name.lower() not in [g.lower() for g in groups]:
        raise AuthError(
            403,
            f"Forbidden: requires group '{group_name}'",
            details={"groups_seen": groups}
        )


def _require_mfa(actor):
    """
    MFA enforcement is tricky because Cognito User Pools access tokens often don't include 'amr'.

    If REQUIRE_MFA=true:
      - If token contains amr and includes "mfa" => OK
      - If token contains amr but no "mfa" => 403
      - If token has no amr at all => 403 with clear message
    If REQUIRE_MFA is not true => no MFA gate (for testing).
    """
    require = os.environ.get("REQUIRE_MFA", "false").lower() == "true"
    if not require:
        return

    amr = actor.get("amr", []) or []
    if not amr:
        raise AuthError(
            403,
            "MFA required but token has no 'amr' claim, so MFA cannot be verified from JWT claims.",
            details={"amr_seen": amr}
        )

    if "mfa" not in amr:
        raise AuthError(
            403,
            "MFA required for approval actions. Please re-authenticate with MFA enabled.",
            details={"amr_seen": amr}
        )


def handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if method == "OPTIONS":
        return resp(200, {"ok": True})

    try:
        actor = _require_authz(event)
        _require_group(actor, "Approver")
        _require_mfa(actor)
    except AuthError as e:
        body = {"error": e.message}
        if e.details:
            body["details"] = e.details
        return resp(e.status_code, body)
    except Exception as ex:
        print("UNHANDLED ERROR:", str(ex))
        return resp(500, {"error": "Internal error (auth)"})

    doc_id = (event.get("pathParameters") or {}).get("documentId")
    if not doc_id:
        return resp(400, {"error": "documentId missing in path"})

    table = ddb.Table(os.environ["DDB_TABLE"])
    pk = f"DOC#{doc_id}"

    meta = table.get_item(Key={"pk": pk, "sk": "METADATA"}).get("Item")
    if not meta:
        return resp(404, {"error": "Document not found"})
    if meta.get("status") != "SUBMITTED":
        return resp(409, {"error": f"Must be SUBMITTED to approve. Current: {meta.get('status')}"})

    owner_user_id = meta.get("ownerUserId")
    if owner_user_id and owner_user_id == actor["sub"]:
        return resp(403, {"error": "Uploader cannot approve their own document"})

    try:
        body = json.loads(event.get("body") or "{}")
    except Exception:
        body = {}
    comment = body.get("comment", "")

    now = utc_now_iso()

    table.update_item(
        Key={"pk": pk, "sk": "METADATA"},
        UpdateExpression="SET #s=:s, approvedAt=:a, approvedBy=:ab, approvedBySub=:abs, updatedAt=:u, gsi1pk=:gpk, gsi1sk=:gsk",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={
            ":s": "APPROVED",
            ":a": now,
            ":ab": actor["username"],
            ":abs": actor["sub"],
            ":u": now,
            ":gpk": "STATUS#APPROVED",
            ":gsk": now
        }
    )

    audit_id = str(uuid.uuid4())
    table.put_item(Item={
        "pk": pk,
        "sk": f"AUDIT#{now}#{audit_id}",
        "eventId": audit_id,
        "eventType": "DOC_APPROVED",
        "timestampUtc": now,
        "actorUserId": actor["sub"],
        "actorUsername": actor["username"],
        "actorEmail": actor.get("email"),
        "actorGroups": actor.get("groups", []),
        "actorAuthTime": actor.get("auth_time"),
        "actorAmr": actor.get("amr", []),
        "details": {
            "env": os.environ.get("ENV_NAME", "dev"),
            "comment": comment,
            "apiRequestId": event.get("requestContext", {}).get("requestId"),
            "routeKey": event.get("routeKey"),
        },
        "integrity": {
            "s3Bucket": meta.get("s3Bucket"),
            "s3Key": meta.get("s3Key"),
            "s3VersionId": meta.get("s3VersionId"),
            "sha256": meta.get("sha256")
        }
    })

    sig_id = str(uuid.uuid4())
    table.put_item(Item={
        "pk": pk,
        "sk": f"ESIG#{now}#{sig_id}",
        "signatureId": sig_id,
        "timestampUtc": now,
        "signerUserId": actor["sub"],
        "signerUsername": actor["username"],
        "signerEmail": actor.get("email"),
        "signerGroups": actor.get("groups", []),
        "signerAuthTime": actor.get("auth_time"),
        "signerAmr": actor.get("amr", []),
        "signerRole": "APPROVER",
        "signatureMeaning": "APPROVE",
        "documentId": doc_id,
        "s3Bucket": meta.get("s3Bucket"),
        "s3Key": meta.get("s3Key"),
        "s3VersionId": meta.get("s3VersionId"),
        "sha256": meta.get("sha256"),
        "attestationText": "I approve this document for use in the validated system.",
        "comment": comment
    })

    return resp(200, {"documentId": doc_id, "status": "APPROVED"})
