import os, json
import boto3
from boto3.dynamodb.conditions import Key

ddb = boto3.resource("dynamodb")

# ---------- Helpers ----------

def resp(code, body):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN", "*"),
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body),
    }


class AuthError(Exception):
    def __init__(self, status_code: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.details = details or {}


def _get_claims(event):
    """
    HTTP API JWT authorizer typically:
      event.requestContext.authorizer.jwt.claims
    """
    rc = event.get("requestContext", {}) or {}
    authz = rc.get("authorizer", {}) or {}

    jwt_block = authz.get("jwt", {}) or {}
    claims = jwt_block.get("claims")
    if claims:
        return claims

    # fallback shape sometimes seen
    if "claims" in authz and authz.get("claims"):
        return authz.get("claims")

    return None


def _normalize_groups(groups_val):
    """
    Normalize Cognito groups to list[str].
    Supports: list, string, "A,B", JSON string '["A"]', bracketed "[A]"
    """
    if groups_val is None:
        return []

    if isinstance(groups_val, list):
        return [str(g).strip() for g in groups_val if str(g).strip()]

    if isinstance(groups_val, str):
        s = groups_val.strip()
        if not s:
            return []

        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(g).strip() for g in arr if str(g).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip().strip('"').strip("'") for p in inner.split(",") if p.strip()]
                return [p.strip().strip('"').strip("'") for p in inner.split() if p.strip()]

        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]

        return [s]

    return [str(groups_val).strip()]


def _require_authz(event):
    claims = _get_claims(event)
    if not claims:
        raise AuthError(401, "Unauthorized (no JWT claims found)")

    groups = _normalize_groups(claims.get("cognito:groups"))
    actor = {
        "sub": claims.get("sub"),
        "email": claims.get("email"),
        "username": claims.get("cognito:username") or claims.get("username") or claims.get("email") or claims.get("sub"),
        "groups": groups,
    }

    if not actor["sub"]:
        raise AuthError(401, "Unauthorized (missing sub claim)")

    return actor


def _require_group(actor, group_name):
    groups = [g.lower() for g in (actor.get("groups") or [])]
    if group_name.lower() not in groups:
        raise AuthError(
            403,
            f"Forbidden: requires group '{group_name}'",
            details={"groups_seen": actor.get("groups")},
        )


def _pick_owner_display(it: dict) -> str:
    """
    Best-effort owner display (email first).
    This prevents your UI from showing UUIDs unless that's all we have.
    """
    return (
        it.get("ownerEmail")
        or it.get("ownerUsername")
        or it.get("submittedByEmail")
        or it.get("submittedBy")
        or it.get("ownerUserId")
        or "—"
    )


# ---------- Handler ----------

def handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if method == "OPTIONS":
        return resp(200, {"ok": True})
    if method != "GET":
        return resp(405, {"error": "Method not allowed"})

    # AuthN/Z
    try:
        actor = _require_authz(event)
        _require_group(actor, "Approver")
    except AuthError as e:
        body = {"error": e.message}
        if e.details:
            body["details"] = e.details
        return resp(e.status_code, body)

    table_name = os.environ.get("DDB_TABLE")
    if not table_name:
        return resp(500, {"error": "Server misconfigured: DDB_TABLE env var missing"})

    table = ddb.Table(table_name)

    items = []
    last_key = None

    try:
        while True:
            kwargs = {
                "IndexName": "gsi1",
                "KeyConditionExpression": Key("gsi1pk").eq("STATUS#SUBMITTED"),
            }
            if last_key:
                kwargs["ExclusiveStartKey"] = last_key

            out = table.query(**kwargs)

            for it in out.get("Items", []):
                if it.get("sk") != "METADATA":
                    continue

                # Return richer owner fields so UI can ALWAYS show email if present
                owner_email = it.get("ownerEmail") or it.get("submittedByEmail")
                owner_username = it.get("ownerUsername") or it.get("submittedBy")
                owner_user_id = it.get("ownerUserId")

                row = {
                    "documentId": it.get("documentId"),
                    "title": it.get("title"),
                    "description": it.get("description"),
                    "submittedAt": it.get("submittedAt"),
                    "status": it.get("status"),

                    # submitter identity (as captured at submit time)
                    "submittedBy": it.get("submittedBy"),
                    "submittedByEmail": it.get("submittedByEmail"),
                    "submittedBySub": it.get("submittedBySub"),

                    # owner identity (as captured at upload-init time, or backfilled at submit)
                    "ownerUserId": owner_user_id,
                    "ownerUsername": owner_username,
                    "ownerEmail": owner_email,

                    # a UI-friendly field (optional but handy)
                    "ownerDisplay": _pick_owner_display({
                        "ownerEmail": owner_email,
                        "ownerUsername": owner_username,
                        "submittedByEmail": it.get("submittedByEmail"),
                        "submittedBy": it.get("submittedBy"),
                        "ownerUserId": owner_user_id,
                    }),

                    "s3Key": it.get("s3Key"),
                    "sha256": it.get("sha256"),
                    "s3VersionId": it.get("s3VersionId"),
                }

                items.append(row)

            last_key = out.get("LastEvaluatedKey")
            if not last_key:
                break

        # newest first by submittedAt (best effort)
        items.sort(key=lambda x: x.get("submittedAt") or "", reverse=True)

        return resp(200, {"count": len(items), "items": items})

    except Exception as e:
        return resp(500, {"error": f"Failed to query pending approvals: {str(e)}"})
