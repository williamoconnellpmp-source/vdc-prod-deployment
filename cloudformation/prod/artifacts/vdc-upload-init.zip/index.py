import os, json, uuid
from datetime import datetime, timezone
import boto3

s3 = boto3.client("s3")
ddb = boto3.resource("dynamodb")

def utc_now_iso():
    return datetime.now(timezone.utc).isoformat()

def resp(code, body):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN", "*"),
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body),
    }

class AuthError(Exception):
    def __init__(self, status_code: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.details = details or {}

def _get_claims(event):
    rc = event.get("requestContext", {}) or {}
    authz = rc.get("authorizer", {}) or {}
    jwt_block = authz.get("jwt", {}) or {}
    claims = jwt_block.get("claims")
    if claims:
        return claims
    if "claims" in authz and authz.get("claims"):
        return authz.get("claims")
    return None

def _normalize_groups(groups_val):
    if groups_val is None:
        return []
    if isinstance(groups_val, list):
        return [str(g).strip() for g in groups_val if str(g).strip()]
    if isinstance(groups_val, str):
        s = groups_val.strip()
        if not s:
            return []
        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(g).strip() for g in arr if str(g).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip().strip('"').strip("'") for p in inner.split(",") if p.strip()]
                return [p.strip().strip('"').strip("'") for p in inner.split() if p.strip()]
        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]
        return [s]
    return [str(groups_val).strip()]

def _normalize_amr(amr_val):
    if amr_val is None:
        return []
    if isinstance(amr_val, list):
        return [str(a).strip() for a in amr_val if str(a).strip()]
    if isinstance(amr_val, str):
        s = amr_val.strip()
        if not s:
            return []
        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(a).strip() for a in arr if str(a).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip() for p in inner.split(",") if p.strip()]
                return [p.strip() for p in inner.split() if p.strip()]
        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]
        return [p.strip() for p in s.split(" ") if p.strip()]
    return [str(amr_val).strip()]

def _looks_like_email(x: str | None) -> bool:
    if not x:
        return False
    s = str(x)
    return ("@" in s) and ("." in s.split("@")[-1])

def _require_authz(event):
    claims = _get_claims(event)
    if not claims:
        raise AuthError(401, "Unauthorized (no JWT claims found)")

    actor_sub = claims.get("sub")
    raw_email = claims.get("email") or claims.get("cognito:email")
    actor_email = raw_email if raw_email else None

    actor_username = (
        claims.get("cognito:username")
        or claims.get("username")
        or actor_email
        or actor_sub
    )

    # fallback: if email missing but username looks like email, use it
    if not actor_email and _looks_like_email(actor_username):
        actor_email = actor_username

    groups = _normalize_groups(claims.get("cognito:groups"))
    amr = _normalize_amr(claims.get("amr"))
    auth_time = claims.get("auth_time")

    actor = {
        "sub": actor_sub,
        "email": actor_email,
        "username": actor_username,
        "groups": groups,
        "amr": amr,
        "auth_time": auth_time,
    }

    # useful debug in dev
    print("DEBUG claims keys:", list(claims.keys()))
    print("DEBUG email:", actor_email)
    print("DEBUG cognito:username:", claims.get("cognito:username"))
    print("DEBUG raw cognito:groups:", claims.get("cognito:groups"))
    print("DEBUG normalized groups:", groups)

    return actor

def _require_group(actor, group_name):
    groups = actor.get("groups", []) or []
    if group_name.lower() not in [g.lower() for g in groups]:
        raise AuthError(403, f"Forbidden: requires group '{group_name}'", details={"groups_seen": groups})

def _safe_filename(name: str) -> str:
    # minimal hardening: strip path, control chars
    name = name.replace("\\", "/").split("/")[-1].strip()
    name = "".join(ch for ch in name if ch.isprintable())
    if not name:
        return ""
    if len(name) > 180:
        name = name[:180]
    return name

def handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method")
    if method == "OPTIONS":
        return resp(200, {"ok": True})
    if method != "POST":
        return resp(405, {"error": "Method not allowed"})

    try:
        actor = _require_authz(event)
        _require_group(actor, "Submitter")
    except AuthError as e:
        body = {"error": e.message, "details": e.details} if e.details else {"error": e.message}
        return resp(e.status_code, body)

    bucket = os.environ["DOCS_BUCKET"]
    table = ddb.Table(os.environ["DDB_TABLE"])
    env_name = os.environ.get("ENV_NAME", "dev")
    ttl = int(os.environ.get("PRESIGN_TTL_SECONDS", "900"))

    try:
        body = json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return resp(400, {"error": "Invalid JSON body"})

    filename = _safe_filename(body.get("filename") or "")
    content_type = (body.get("contentType") or "application/octet-stream").strip()

    if not filename:
        return resp(400, {"error": "filename is required"})

    document_id = str(uuid.uuid4())
    now = utc_now_iso()
    key = f"{env_name}/documents/{document_id}/{filename}"

    presigned = s3.generate_presigned_url(
        "put_object",
        Params={"Bucket": bucket, "Key": key, "ContentType": content_type},
        ExpiresIn=ttl,
    )

    owner_user_id = actor.get("sub") or "unknown"
    owner_username = actor.get("username") or owner_user_id
    owner_email = actor.get("email")

    meta = {
        "pk": f"DOC#{document_id}",
        "sk": "METADATA",
        "documentId": document_id,
        "status": "DRAFT",
        "s3Bucket": bucket,
        "s3Key": key,
        "s3VersionId": None,
        "contentType": content_type,
        "sha256": None,
        "ownerUserId": owner_user_id,
        "ownerUsername": owner_username,
        "ownerEmail": owner_email,
        "title": None,
        "description": None,
        "createdAt": now,
        "updatedAt": now,
        "gsi1pk": "STATUS#DRAFT",
        "gsi1sk": now,
    }
    table.put_item(Item=meta)

    audit_id = str(uuid.uuid4())
    table.put_item(Item={
        "pk": f"DOC#{document_id}",
        "sk": f"AUDIT#{now}#{audit_id}",
        "eventId": audit_id,
        "eventType": "DOC_UPLOAD_INITIATED",
        "timestampUtc": now,
        "actorUserId": owner_user_id,
        "actorUsername": owner_username,
        "actorEmail": owner_email,
        "actorGroups": actor.get("groups", []),
        "actorAuthTime": actor.get("auth_time"),
        "actorAmr": actor.get("amr", []),
        "details": {
            "filename": filename,
            "contentType": content_type,
            "env": env_name,
            "apiRequestId": event.get("requestContext", {}).get("requestId"),
            "routeKey": event.get("routeKey"),
        },
        "integrity": {"s3Bucket": bucket, "s3Key": key, "s3VersionId": None, "sha256": None},
    })

    return resp(200, {
        "documentId": document_id,
        "upload": {"bucket": bucket, "key": key, "contentType": content_type, "presignedUrl": presigned, "expiresInSeconds": ttl},
    })
