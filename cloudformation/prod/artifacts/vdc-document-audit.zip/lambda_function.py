import os, json
import boto3

ddb = boto3.resource("dynamodb")

def resp(code, body):
    return {
        "statusCode": code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": os.environ.get("CORS_ALLOW_ORIGIN","*"),
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        },
        "body": json.dumps(body)
    }

class AuthError(Exception):
    def __init__(self, status_code: int, message: str, details: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.details = details or {}

def _get_claims(event):
    rc = event.get("requestContext", {}) or {}
    authz = rc.get("authorizer", {}) or {}
    jwt_block = authz.get("jwt", {}) or {}
    claims = jwt_block.get("claims")
    if claims:
        return claims
    if "claims" in authz and authz.get("claims"):
        return authz.get("claims")
    return None

def _normalize_groups(groups_val):
    if groups_val is None:
        return []
    if isinstance(groups_val, list):
        return [str(g).strip() for g in groups_val if str(g).strip()]
    if isinstance(groups_val, str):
        s = groups_val.strip()
        if not s:
            return []
        if s.startswith("[") and s.endswith("]"):
            try:
                arr = json.loads(s)
                if isinstance(arr, list):
                    return [str(g).strip() for g in arr if str(g).strip()]
            except Exception:
                inner = s[1:-1].strip()
                if not inner:
                    return []
                if "," in inner:
                    return [p.strip().strip('"').strip("'") for p in inner.split(",") if p.strip()]
                return [p.strip().strip('"').strip("'") for p in inner.split() if p.strip()]
        if "," in s:
            return [p.strip() for p in s.split(",") if p.strip()]
        return [s]
    return [str(groups_val).strip()]

def _require_authz(event):
    claims = _get_claims(event)
    if not claims:
        raise AuthError(401, "Unauthorized (no JWT claims found)")
    return {"sub": claims.get("sub"), "groups": _normalize_groups(claims.get("cognito:groups"))}

def _has_group(actor, name):
    groups = [g.lower() for g in (actor.get("groups") or [])]
    return name.lower() in groups

def handler(event, context):
    method = event.get("requestContext",{}).get("http",{}).get("method")
    if method == "OPTIONS":
        return resp(200, {"ok": True})
    if method != "GET":
        return resp(405, {"error": "Method not allowed"})

    try:
        actor = _require_authz(event)
        if not (_has_group(actor, "Approver") or _has_group(actor, "Submitter")):
            raise AuthError(403, "Forbidden: requires Submitter or Approver group", details={"groups_seen": actor.get("groups")})
    except AuthError as e:
        body = {"error": e.message, "details": e.details} if e.details else {"error": e.message}
        return resp(e.status_code, body)

    doc_id = (event.get("pathParameters") or {}).get("documentId")
    if not doc_id:
        return resp(400, {"error":"documentId missing in path"})

    table = ddb.Table(os.environ["DDB_TABLE"])
    pk = f"DOC#{doc_id}"

    try:
        out = table.query(
            KeyConditionExpression="pk = :pk",
            ExpressionAttributeValues={":pk": pk}
        )

        raw = out.get("Items", [])
        items = []

        for it in raw:
            sk = it.get("sk","")
            if sk.startswith("AUDIT#") or sk.startswith("ESIG#"):
                items.append(it)

        items.sort(key=lambda x: x.get("sk",""), reverse=False)

        return resp(200, {"documentId": doc_id, "count": len(items), "items": items})

    except Exception as e:
        return resp(500, {"error": f"Failed to fetch audit trail: {str(e)}"})
